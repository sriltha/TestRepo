package com.org.incedo.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.org.incedo.security.JwtTokenProvider;
import com.org.incedo.service.CommonService;
import com.org.incedo.service.LdapService;

import net.sf.json.JSONObject;

@RestController
public class ApiController {

	private static final Logger logger = LoggerFactory.getLogger(ApiController.class);


	@Autowired
	CommonService commonService;

	@Autowired
	LdapService ldapService;

	@Autowired
	JwtTokenProvider tokenProvider;

	@PostMapping("/login")
	public String login(@RequestBody String payload) {
		logger.info("login ==> payload : " + payload);
		return  ldapService.authenticateUser(payload);
	}

	@GetMapping("/routes/{project_id}/{token}")
	public String routesfunc(@PathVariable Integer project_id, @PathVariable String token) {
		logger.info("routesfunc ==> project_id : " + project_id + " :token :" + token);
		return commonService.routes(project_id,token);

	}

	@GetMapping("/kpiMaster/{tree_id}/{token}")
	public String kpiMasterfunc(@PathVariable Integer tree_id, @PathVariable String token) {
		logger.info("kpiMasterfunc ==> tree_id : " + tree_id + " :token :" + token);
		return commonService.kpiMasterfunc(tree_id,token);
	}

	@GetMapping("/dynamicKpiTree/{token}")
	public String dynamicTree(@PathVariable String token) {
		logger.info("dynamicTree ==> token :" + token);
		return commonService.dynamicTree(token);
	}
	
	@GetMapping("/KpiTreeList/{token}")
	public String treeList(@PathVariable String token) {
		logger.info("treeList ==> token :" + token);
		return commonService.treeList(token);

	}
	
		@RequestMapping(value="/saveKpiTree/{token}/{tree_id}",
			method= {RequestMethod.GET, RequestMethod.POST,RequestMethod.PUT})
	public String saveDynamicTree(@PathVariable Integer tree_id, 
			@PathVariable String token,@RequestBody(required = false) String payload, 
			final HttpServletRequest request) {
		logger.info("saveDynamicTree ==> tree_id : " + tree_id + " :token :" + token);
		return commonService.saveDynamicTree(tree_id, payload, request.getMethod(),token);
	}
	
	
	@GetMapping("/kpiTree/{tree_id}/{token}")
	public String kpiTreefunc(@PathVariable Integer tree_id, @PathVariable String token) {
		logger.info("kpiTreefunc ==> tree_id : " + tree_id + " :token :" + token);
		return commonService.kpiTreefunc(tree_id,token);

	}
		
	@GetMapping("/cohortTable/{tree_id}/{kpi_id}/{token}")
	public String cohortTableValues(@PathVariable Integer tree_id, @PathVariable Integer kpi_id,
			@PathVariable String token) {
		logger.info("cohortTableValues ==> tree_id : " + tree_id + " :kpi_id :" + kpi_id + " :token :" + token);
		return commonService.cohortTableValues(tree_id, kpi_id,token);

	}
	
	@GetMapping("/cohortLineChart/{tree_id}/{kpi_id}/{token}")
	public String kpivalues(@PathVariable Integer tree_id, @PathVariable Integer kpi_id,
			@PathVariable String token) {
		logger.info("kpivalues ==> tree_id : " + tree_id + " :kpi_id :" + kpi_id + " :token :" + token);
		return commonService.kpivalues(tree_id, kpi_id,token);
	}
	
	@GetMapping("/cohortKeyInsight/{tree_id}/{kpi_id}/{token}")
	public String nlgValues(@PathVariable Integer tree_id, @PathVariable Integer kpi_id,
			@PathVariable String token) {
		logger.info("nlgValues ==> tree_id : " + tree_id + " :kpi_id :" + kpi_id + " :token :" + token);
		return commonService.nlgValues(tree_id, kpi_id,token);
	}
	
	@RequestMapping(value = "/mainMenu/{project_id}/{token}", 
			method = { RequestMethod.GET, RequestMethod.POST,RequestMethod.PUT })
	public String mainMenu(@PathVariable Integer project_id, @PathVariable String token,
			@RequestBody(required = false) String payload, final HttpServletRequest request) {
		logger.info("mainMenu ==> project_id : " + project_id + " :token :" + token);
		return commonService.mainMenu(project_id, payload, request.getMethod(),token);
	}
}
