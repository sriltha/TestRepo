package com.org.incedo.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.incedo.payload.ApiResponse;
import com.org.incedo.payload.JwtAuthResponse;
import com.org.incedo.payload.LoginRequest;
import com.org.incedo.payload.ValidateTokenRequest;
import com.org.incedo.security.JwtTokenProvider;
import com.org.incedo.util.Constants;



@RestController
@RequestMapping("/api/auth")
public class GreetController {

	private static final Logger logger = LoggerFactory.getLogger(GreetController.class);
	
    @Autowired
    AuthenticationManager authenticationManager;
    
    @Autowired
    JwtTokenProvider tokenProvider;
    
    
	@GetMapping("greet")
	public String greet() {
		return "Welcome to home page";
	}
	
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
		
    	logger.info("authenticateUser ::::::Username : " + loginRequest.getUsername() + "Password :"+loginRequest.getPassword());

    	if(loginRequest.getUsername().isEmpty() || loginRequest.getPassword().isEmpty()) {
    		 return new ResponseEntity(new ApiResponse(false, Constants.USERNAME_OR_PASSWORD_INVALID),
                     HttpStatus.BAD_REQUEST);
    	}
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );
        String jwt = tokenProvider.generateToken(authentication);
        return ResponseEntity.ok(new JwtAuthResponse(jwt));
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping("/validatetoken")
    public ResponseEntity<?> getTokenByCredentials(@Valid @RequestBody ValidateTokenRequest validateToken) {
    	
    	logger.info("getTokenByCredentials ::::::Token : " + validateToken.getToken());
    	
    	String username = null;
    	 String jwt =validateToken.getToken();
         if (StringUtils.hasText(jwt) && tokenProvider.validateToken(jwt)) {
                username = tokenProvider.getUsernameFromJWT(jwt);
	          //If required we can have one more check here to load the user from LDAP server
             return ResponseEntity.ok(new ApiResponse(Boolean.TRUE,Constants.VALID_TOKEN + username));
           }else {
        	   return new ResponseEntity(new ApiResponse(false, Constants.INVALID_TOKEN),
                       HttpStatus.BAD_REQUEST);
           }
         
    }
}
