package com.org.incedo;

import java.sql.*;
import java.util.Properties;

class Test {
  public static void main(String[] args) {

    try {
    	String url = "jdbc:postgresql://idsp.incedolabs.com:5432/incedodsp";
    	Properties props = new Properties();
    	props.setProperty("user","postgres");
    	props.setProperty("password","Airflow@99");
//    	props.setProperty("ssl","false");
    	Connection conn = DriverManager.getConnection(url, props);

  //  	String url = "jdbc:postgresql://localhost/test?user=fred&password=secret&ssl=true";
  //  	Connection conn = DriverManager.getConnection(url);
    	
 //     Connection conn = DriverManager.getConnection("jdbc:presto://idsp.incedolabs.com:8084/postgresql/incedo_dsp_schema?user=postgres");
      Statement stmt = conn.createStatement();
      try {
      	stmt.executeUpdate("UPDATE incedo_dsp_schema.savedKpiTree set kpi_tree_desc='Test KPI6' where kpi_tree_id=6");
/*      	
        ResultSet rs = stmt.executeQuery("SELECT * from incedo_dsp_schema.savedKpiTree where kpi_tree_id=6");
        while(rs.next()) {
        	System.out.println( rs.getString(1));
        	System.out.println( rs.getString(2));
        	System.out.println( rs.getString(3));
        	System.out.println( rs.getString(4));
        	stmt.executeUpdate("UPDATE incedo_dsp_schema.savedKpiTree set kpi_tree_desc='Test KPI5' where kpi_tree_id=6");
//            System.out.println(String.format("time=%s, method=%s, path=%s", time, method, path));
        }*/
      }
      finally {
        stmt.close();
        conn.close();
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
} 