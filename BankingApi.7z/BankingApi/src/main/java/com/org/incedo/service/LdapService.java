package com.org.incedo.service;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Base64;

import javax.naming.AuthenticationException;
import javax.naming.AuthenticationNotSupportedException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.org.incedo.controller.ApiController;
import com.org.incedo.security.JwtTokenProvider;
import com.org.incedo.util.JsonUtil;

import net.sf.json.JSONObject;

@Configuration
public class LdapService {
	
	private static final Logger logger = LoggerFactory.getLogger(LdapService.class);


	@Value("${ldap.url}")
	private String url;
	
	@Value("${ldapUsername}")
	private String ldapUsername;	

	@Value("${ldapPassword}")
	private String ldapPassword;

	@Value("${ldapMainOU}")
	private String ldapMainOU;

	@Autowired
	JwtTokenProvider tokenProvider;


	public String authenticateUser(String payload) {
		String result=null;
		JSONObject jsonObj = JSONObject.fromObject(payload);
		String username = jsonObj.getString("username");
		String password = jsonObj.getString("password");
		LdapContext ctx = null;
		InitialDirContext inidircontext=null;
		String user = "uid=" + username + ",ou=Data_Science,dc=idsp,dc=com";

		try {
			Hashtable<String, String> env = new Hashtable<String, String>();

			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, url);
			env.put(Context.SECURITY_PRINCIPAL, user);
			env.put(Context.SECURITY_CREDENTIALS, password);
			logger.info("Attempting to Connect...");
			ctx = new InitialLdapContext(env, null);
			inidircontext = new InitialDirContext(env);

			logger.info("Connection Successful.");
			String[] attrIDs = { "cn", "mail", "title","jpegPhoto" };

			SearchControls ctls = new SearchControls();
			ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			ctls.setReturningAttributes(attrIDs);
			String filter = "(&(objectClass=*))";

			NamingEnumeration e = ctx.search(user, filter, ctls);

			if (e.hasMore()) {
				Attributes attrs = ((SearchResult) e.next()).getAttributes();
				String jwt = tokenProvider.generateToken(username);
				String name= (String) attrs.get("cn").get();
				String position= (String) attrs.get("title").get();
				String mail= (String) attrs.get("mail").get();
				byte[] jpegPhoto= (byte[]) attrs.get("jpegPhoto").get();		
//				String profilePic  = Base64.getMimeEncoder().encodeToString((byte[]) att.get());
				String profilePic = Base64.getEncoder().encodeToString(jpegPhoto);

				
				String[] memberOf=getGroups(inidircontext,username,user);
				JSONObject obj = new JSONObject();
				obj.put("token", jwt);
				obj.put("name", name);
				obj.put("position", position);
				obj.put("mail", mail);
				obj.put("profilePic", profilePic);
				obj.put("memberOf", memberOf);
				
				result =JsonUtil.response(obj.toString(), true);
				logger.info("User: "+ obj.toString());	
				ctx.close();
				inidircontext.close();
			}
		} catch (AuthenticationNotSupportedException ex) {
			logger.error("The authentication is not supported by the server");
			result =JsonUtil.response("The authentication is not supported by the server", false);
		} catch (AuthenticationException ex) {
			logger.error("Invalid credentials");
			result =JsonUtil.response("Invalid credentials", false);
		} catch (NamingException ex) {
			logger.error("error when trying to create the context");
			result =JsonUtil.response("error when trying to create the context", false);
		} 
		return result;
	}

	public String[] getGroups(InitialDirContext context, String username, String user) throws NamingException {
		List<String> groups = new ArrayList<String>();
		String[] attrIdsToSearch = new String[] { "memberOf" };
		String SEARCH_BY_SAM_ACCOUNT_NAME = "(&(cn=*)(objectClass=*))"; // "(&(objectClass=*))";
		String filter = String.format(SEARCH_BY_SAM_ACCOUNT_NAME, username);
		SearchControls constraints = new SearchControls();
		constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
		constraints.setReturningAttributes(attrIdsToSearch);
		NamingEnumeration results = context.search(user, filter, constraints);
		// Fail if no entries found
		if (results == null || !results.hasMore()) {
			System.out.println("No result found");
			return new String[] {  };
		}
		SearchResult result = (SearchResult) results.next();
		Attributes attrs = result.getAttributes();
		Attribute attr = attrs.get(attrIdsToSearch[0]);

		NamingEnumeration e = attr.getAll();
		logger.info(username + " is Member of the following groups  : \n");
		while (e.hasMore()) {
			String value = getCN(e.next().toString());
			groups.add(value);
			System.out.println(value);
		}
		return groups.toArray(new String[groups.size()]);		
		
	}
	
	public String getLdapGroupNames(String token) {
		
		String vtoken = tokenProvider.validateToken(token);
		if(! vtoken.equals("vaild")) {
			logger.error("modeldescription : " + vtoken);
			return JsonUtil.response(vtoken, false);	
		}
		
		String response=null;
		LdapContext ctx = null;
		InitialDirContext inidircontext=null;
		List<String> groups = new ArrayList<String>();
		String user = "uid=" + ldapUsername + ",ou=Data_Science,dc=idsp,dc=com";
		try {
			Hashtable<String, String> env = new Hashtable<String, String>();

			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, url);
			env.put(Context.SECURITY_PRINCIPAL, user);
			env.put(Context.SECURITY_CREDENTIALS, ldapPassword);
			System.out.println("Attempting to Connect...");
			ctx = new InitialLdapContext(env, null);
			inidircontext = new InitialDirContext(env);

			logger.info("Connection Successful.");
			

		String[] attrIdsToSearch = new String[] { "*" };
		String SEARCH_BY_SAM_ACCOUNT_NAME = "(&(cn=*)(objectClass=*))"; // "(&(objectClass=*))";
		String filter = String.format(SEARCH_BY_SAM_ACCOUNT_NAME, ldapUsername);
		SearchControls constraints = new SearchControls();
		constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
		constraints.setReturningAttributes(attrIdsToSearch);
		NamingEnumeration results = inidircontext.search(user, filter, constraints);
		// Fail if no entries found
		if (results == null || !results.hasMore()) {
			logger.info("No result found");
			response= JsonUtil.response(new String[] {  }, true);
		}
		SearchResult result = (SearchResult) results.next();
		Attributes attrs = result.getAttributes();
		Attribute attr = attrs.get(attrIdsToSearch[0]);

		NamingEnumeration e = attr.getAll();
		logger.info(ldapUsername + " is Member of the following groups  : \n");
		while (e.hasMore()) {
			String value = getCN(e.next().toString());
			groups.add(value);
			logger.info(value);
		}		
		ctx.close();
		inidircontext.close();		
		} catch (AuthenticationNotSupportedException ex) {
			logger.error("The authentication is not supported by the server");
			response= JsonUtil.response("The authentication is not supported by the server", false);
		} catch (AuthenticationException ex) {
			logger.error("Invalid credentials");
			response= JsonUtil.response("Invalid credentials", false);
		} catch (NamingException ex) {
			logger.error("error when trying to create the context");
			response= JsonUtil.response("error when trying to create the context", false);
		} 
		String [] result= groups.toArray(new String[groups.size()]);
		logger.info("getLdapGroupNames result: "+ result);			
		response= JsonUtil.response(result, true);
		return response;
	}


	
	    public static String getCN(String cnName) {
	        if (cnName != null && cnName.toUpperCase().startsWith("CN=")) {
	            cnName = cnName.substring(3);
	        }
	        int position = cnName.indexOf(',');
	        if (position == -1) {
	            return cnName;
	        } else {
	            return cnName.substring(0, position);
	        }
	    }
	
}
