package com.org.incedo.util;

import java.util.ArrayList;
import java.util.List;

public class Node {
	
	String name;
	int kpi_id;
	int parent_id;
	String relation;
	String statusval;
	String attributes;
    private Node parent;    
    private List<Node> children;
 
	
    public Node() {
        super();
        this.children = new ArrayList<>();
    }
    
    public Node(String name, String relation,String statusval,String attributes,int kpi_id, int parent_id) {
        this.name = name;
        this.relation = relation;
        this.statusval = statusval;
        this.attributes = attributes;
        
        this.kpi_id = kpi_id;
        this.parent_id = parent_id;
        this.children = new ArrayList<>();
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getKpi_id() {
		return kpi_id;
	}

	public void setKpi_id(int kpi_id) {
		this.kpi_id = kpi_id;
	}

	public int getParent_id() {
		return parent_id;
	}

	public void setParent_id(int parent_id) {
		this.parent_id = parent_id;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getStatusval() {
		return statusval;
	}

	public void setStatusval(String statusval) {
		this.statusval = statusval;
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public Node getParent() {
		return parent;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	public List<Node> getChildren() {
		return children;
	}

	public void setChildren(List<Node> children) {
		this.children = children;
	}
    public void addChild(Node child) {
        if (!this.children.contains(child) && child != null)
            this.children.add(child);
    }
    
    @Override
    public String toString() {
        return "Node [id=" + kpi_id + ", parentId=" + parent_id + ", value=" + name + ", children="
                + children + "]";
    }
}

