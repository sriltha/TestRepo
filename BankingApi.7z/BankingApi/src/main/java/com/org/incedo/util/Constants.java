package com.org.incedo.util;

public interface Constants {
	
	String INVALID_TOKEN = "Invalid Token";
	String VALID_TOKEN = "Valid token for user ";
	String USERNAME_OR_PASSWORD_INVALID = "Username or Password should not be empty";

}
