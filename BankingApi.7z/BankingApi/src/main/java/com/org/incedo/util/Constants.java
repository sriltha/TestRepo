package com.org.incedo.util;

public interface Constants {
	String INVALID_TOKEN = "Invalid Token";
	String VALID_TOKEN = "Valid token for user ";
	String USERNAME_OR_PASSWORD_INVALID = "Invalid credentials";
	String PROGRAM = "idspAPI";
	String RELEASE = "1";
	String VERSION = "0.0.1";
	String FAIL = "fail";
	int ERROR = 400;
	String SUCCESS = "success";
	String OK = "OK";
	int PASS = 200;

}
