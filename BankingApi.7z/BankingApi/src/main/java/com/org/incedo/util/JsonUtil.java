package com.org.incedo.util;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;

public class JsonUtil {

	public static String listmap_to_json_string(List<Map<String, Object>> list) {
		JSONArray json_arr = new JSONArray();
		for (Map<String, Object> map : list) {
			JSONObject json_obj = new JSONObject();
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				String key = entry.getKey();
				Object value = (entry.getValue() != null ? entry.getValue() : null);
				System.out.println("key: "+ key);
				System.out.println("value: "+ value);
				try {
					json_obj.put(key, value);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			json_arr.add(json_obj);
		}
		return json_arr.toString();
	}
	
	public static String listmap_to_json_array(List<Map<String, Object>> list) {
		String result = "";
		for (Map<String, Object> map : list) {
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				String key = entry.getKey();
				Object value = (entry.getValue() != null ? entry.getValue() : null);
				System.out.println("key: "+ key);
				System.out.println("value: "+ value);
				result= value.toString();
			}
		}
		return result;
	}
	
  	public static String listmap_to_json_kpitree(List<Map<String, Object>> list,int kpi_id) {
  		String compute="";

  		List<JSONObject> nodes = new ArrayList<>();
		for (Map<String, Object> map : list) {
			JSONObject json_obj = new JSONObject();
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				String key = entry.getKey();
				String value = (entry.getValue() != null ? entry.getValue().toString() : null);
				json_obj.put(key, value);
			}
			nodes.add(json_obj);
		}

		
		for (int i=0;i < nodes.size(); i++) {
			JSONObject jsonObject = nodes.get(i);
			if(Integer.parseInt(jsonObject.get("kpi_id").toString())== kpi_id) {
				nodes.remove(nodes.get(i));
				compute=	childrens(nodes,kpi_id);
				break ;
			}
		}
		return compute;
	}
		
	public static String childrens(List<JSONObject> nodes, int kpi_id ) {
		JSONObject test = new JSONObject();
		for (int i = 0; i < nodes.size(); i++) {
			JSONObject jsonObject = nodes.get(i);
			if (Integer.parseInt(jsonObject.get("parent_id").toString()) == kpi_id) {
				int parentid = Integer.parseInt(jsonObject.get("parent_id").toString());
				nodes.remove(nodes.get(i));
				if (!nodes.isEmpty()) {
					test.put("children", childrens(nodes, parentid));
				}
				break;
			}
		}
		return test.toString();
		
	}

	
	public static JSONArray listmap_to_json(List<Map<String, Object>> list) {
		JSONArray json_arr = new JSONArray();
		for (Map<String, Object> map : list) {
			JSONObject json_obj = new JSONObject();
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				String key = entry.getKey();
				Object value = (entry.getValue() != null ? entry.getValue() : null);
				try {
					json_obj.put(key, value);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			json_arr.add(json_obj);
		}
		return json_arr;
	}

	public static String response(Object result, boolean flg) {
		Instant instant = Instant.now();
		JSONObject obj = new JSONObject();
		obj.put("program", Constants.PROGRAM);
		obj.put("release", Constants.RELEASE);
		obj.put("version", Constants.VERSION);
		obj.put("datetime", instant.toString().replaceAll("[TZ]", " "));
		obj.put("timestamp", String.valueOf(instant.toEpochMilli()));
		if (flg) {
			obj.put("status", Constants.SUCCESS);
			obj.put("code", Constants.PASS);
			obj.put("message", Constants.OK);
			obj.put("response", result);
		} else {
			obj.put("status", Constants.FAIL);
			obj.put("code", Constants.ERROR);
			obj.put("message", result);
		}
		return obj.toString();
	}
	
	public static String list_mapto_parentchild(List<Map<String, Object>> list) {
		List<Node> nodes = new ArrayList<Node>();
		for (Map<String, Object> map : list) {
				Node node = new Node();
				ModelMapper modelMapper = new ModelMapper();
				modelMapper.map(map, node);
				nodes.add(node);		
		}
		Node node =createTree(nodes);
		return JSONObject.fromObject(node).toString();

	}
	
	   private static Node createTree(List<Node> nodes) {

	        Map<Integer, Node> mapTmp = new HashMap<>();
	        
	        //Save all nodes to a map
	        for (Node current : nodes) {
	            mapTmp.put(current.getKpi_id(), current);
	        }

	        //loop and assign parent/child relationships
	        for (Node current : nodes) {
	        	Integer parentId = current.getParent_id();

	            if (parentId != null) {
	                Node parent = mapTmp.get(parentId);
	                if (parent != null) {
	                    current.setParent(parent);
	                    parent.addChild(current);
	                    mapTmp.put(parentId, parent);
	                    mapTmp.put(current.getKpi_id(), current);
	                }
	            }

	        }

	    
	        //get the root
	        Node root = null;
	        for (Node node : mapTmp.values()) {
	            if(node.getParent() == null) {
	                root = node;
	                break;
	            }
	        }
System.out.println(root.toString());
	        return root;
	    }

}
