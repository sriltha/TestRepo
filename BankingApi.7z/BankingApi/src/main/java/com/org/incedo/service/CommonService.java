package com.org.incedo.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.org.incedo.dao.CommonDao;
import com.org.incedo.security.JwtTokenProvider;
import com.org.incedo.util.JsonUtil;

import net.sf.json.JSONObject;

@Component
public class CommonService {
	
    private static final Logger logger = LoggerFactory.getLogger(CommonService.class);

	@Autowired
	JwtTokenProvider tokenProvider;
	
	@Autowired
	CommonDao commonDao;

	public String routes(int projectid,String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("routes : " + result);
			return JsonUtil.response(result, false);	
		}		
		return commonDao.routes(projectid);
	}

	public String kpiMasterfunc(int tree_id,String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("kpiMasterfunc : " + result);
			return JsonUtil.response(result, false);	
		}
		return commonDao.kpiMasterfunc(tree_id);
	}
	
	public String dynamicTree(String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("dynamicTree : " + result);
			return JsonUtil.response(result, false);	
		}
		return commonDao.dynamicTree();
	}
	
	public String kpiTreefunc(int tree_id,String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("kpiTreefunc : " + result);
			return JsonUtil.response(result, false);	
		}	
		return commonDao.kpiTreefunc(tree_id);
	}
	
	public String treeList(String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("treeList : " + result);
			return JsonUtil.response(result, false);	
		}	
		return commonDao.treeList();
	}

	public String saveDynamicTree(int tree_id, String payload, String method,String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("saveDynamicTree : " + result);
			return JsonUtil.response(result, false);	
		}	
		if (method.equalsIgnoreCase("GET")) {
			return commonDao.getSaveDynamicTree(tree_id);
		}
		if (payload == null)
			return JsonUtil.response("no Data to Update", false);
		
		if (method.equalsIgnoreCase("PUT")) {
			return commonDao.putSaveDynamicTree(tree_id, payload);
		}
		if (method.equalsIgnoreCase("POST")) {
			return commonDao.postSaveDynamicTree(tree_id, payload);
		}
		return null;
}

	public String mainMenu(Integer project_id, String payload, String method,String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("modeldescription : " + result);
			return JsonUtil.response(result, false);	
		}	
		
		if (method.equalsIgnoreCase("GET")) {
			return commonDao.getMainMenu(project_id);
		}
		if (payload == null)
			return JsonUtil.response("no Data to Update", false);
		
		if (method.equalsIgnoreCase("PUT")) {
			return commonDao.putMainMenu(project_id, payload);

		}
		if (method.equalsIgnoreCase("POST")) {
			return commonDao.postMainMenu(project_id, payload);
		}
		return null;
	}

	public String cohortTableValues(int tree_id, int kpi_id,String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("cohortTableValues : " + result);
			return JsonUtil.response(result, false);	
		}	
		return commonDao.cohortTableValues(tree_id,kpi_id);
	}

	public String kpivalues(Integer tree_id, Integer kpi_id, String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("kpivalues : " + result);
			return JsonUtil.response(result, false);	
		}	
		return commonDao.kpivalues(tree_id,kpi_id);
	}

	public String nlgValues(Integer tree_id, Integer kpi_id, String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("nlgValues : " + result);
			return JsonUtil.response(result, false);	
		}	
		return commonDao.nlgValues(tree_id,kpi_id);
	}

	public String echart(Integer tree_id, Integer kpi_id, String token) {
		String result = tokenProvider.validateToken(token);
		if(! result.equals("vaild")) {
			logger.error("echart : " + result);
			return JsonUtil.response(result, false);	
		}	
		return commonDao.echart(tree_id,kpi_id);
	}
	








	
}
