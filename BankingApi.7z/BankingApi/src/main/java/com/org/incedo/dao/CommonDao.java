package com.org.incedo.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.org.incedo.util.JsonUtil;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Repository
public class CommonDao {
	private static final Logger logger = LoggerFactory.getLogger(CommonDao.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public String routes(Integer id) {
		String sql = "SELECT * FROM incedo_dsp_schema.routes where project_id= " + id;
		logger.info("routes SQL : " + sql);
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("routes ::::::results : " + results.size());
		String json = JsonUtil.listmap_to_json_string(results);
		return JsonUtil.response(json, true);

	}
	
	public String kpiMasterfunc(Integer id) {
		String sql = "SELECT kpi_id,kpi_description FROM incedo_dsp_schema.kpiMaster where tree_id= " + id;
		logger.info("kpiMasterfunc SQL : " + sql );
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("kpiMasterfunc ::::::results : " + results.size());
		String json = JsonUtil.listmap_to_json_string(results);
		return JsonUtil.response(json, true);
	}
	
	public String dynamicTree() {
		String sql = "SELECT * FROM incedo_dsp_schema.dataCatalog";
		logger.info("dynamicTree SQL : " + sql );
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("dynamicTree ::::::results : " + results.size());
		String json = JsonUtil.listmap_to_json_string(results);
		return JsonUtil.response(json, true);
	}
	
	public String kpiTreefunc(Integer id) {
		String sql = "select km.kpi_description as name, kt.kpi_id, kt.parent_id, kt.relation, kt.statusval, kt.attributes "
				+ "from incedo_dsp_schema.kpitreevalue as kt join incedo_dsp_schema.kpimaster as km on kt.tree_id=km.tree_id and kt.kpi_id=km.kpi_id where kt.tree_id="+ id;
		logger.info("kpiTreefunc SQL : " + sql );
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("kpiTreefunc ::::::results : " + results.size());
		String json = JsonUtil.listmap_to_json_kpitree(results,id);
		return JsonUtil.response(json, true);
	}
	
	public String treeList() {
		String sql = "SELECT kpi_tree_id as treeID,kpi_tree_desc as treeDesc from incedo_dsp_schema.savedkpitree";
		logger.info("treeList SQL : " + sql );
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("treeList ::::::results : " + results.size());
		String json = JsonUtil.listmap_to_json_string(results);
		return JsonUtil.response(json, true);
	}

	
	public String cohortTableValues(int tree_id, int kpi_id) {
	    String sql="SELECT rootcause_description as rootcause,kpi_value_current as current_value,kpi_value_previous as previous_value,"
	    		+ "kpi_value_change as change,kpi_value_contribution as contribution,statusval as status "
	    		+ "from incedo_dsp_schema.kpianomalyvalues where kpi_id="+kpi_id+" and tree_id="+ tree_id;
	    logger.info("cohortTableValues SQL : " + sql );
	    List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("cohortTableValues ::::::results : " + results.size());
		String json= JsonUtil.listmap_to_json_string(results);
		return  JsonUtil.response(json, true);
	}
	
	public String kpivalues(int tree_id, int kpi_id) {
	    String sql="select km.kpi_representation as kpi_type, kt.kpi_value_date as kpi_value_date, kt.kpi_value as KPI, "
	    		+ "kt.kpi_low_acceptance_range as Low_Acceptance_Range, kt.kpi_high_acceptance_range as High_Acceptance_Range,kt.anomaly_values as Anomaly "
	    		+ "from incedo_dsp_schema.kpiactualvalues as kt join incedo_dsp_schema.kpimaster as km on kt.tree_id=km.tree_id and kt.kpi_id=km.kpi_id where kt.tree_id="+tree_id+" and kt.kpi_id="+kpi_id;
	    logger.info("kpivalues SQL : " + sql );
	    List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("kpivalues ::::::results : " + results.size());
		String json= JsonUtil.listmap_to_json_string(results);
		return  JsonUtil.response(json, true);
	}

	public String nlgValues(int tree_id, int kpi_id) {
		String sql="SELECT nlg_description as Key_Insights,description_date as Date from incedo_dsp_schema.kpinlgdetails where kpi_id= "+kpi_id+" and tree_id= "+ tree_id;
		logger.info("nlgValues SQL : " + sql );
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("nlgValues ::::::results : " + results.size());
		String json= JsonUtil.listmap_to_json_string(results);
		return  JsonUtil.response(json, true);
	}

	public String echart(int tree_id, int kpi_id) {
		String sql="select km.kpi_representation as kpi_type, kt.kpi_value_date as kpi_value_date, kt.kpi_value as KPI, "
	    		+ "kt.kpi_low_acceptance_range as Low_Acceptance_Range, kt.kpi_high_acceptance_range as High_Acceptance_Range,kt.anomaly_values as Anomaly "
	    		+ "from incedo_dsp_schema.kpiactualvalues as kt join incedo_dsp_schema.kpimaster as km on kt.tree_id=km.tree_id and kt.kpi_id=km.kpi_id where kt.tree_id="+tree_id+" and kt.kpi_id="+ kpi_id
	    				+ " order by kpi_value_date ";
		logger.info("echart SQL : " + sql );
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("echart ::::::results : " + results.size());
		String json= JsonUtil.listmap_to_json_string(results);
		return  JsonUtil.response(json, true);
	}
	
	
	public String getSaveDynamicTree(Integer id) {

		String sql = "SELECT kpi_tree_id as treeID,kpi_tree_desc as treeDesc,raw_tree as rawTree,tree_json as jsonTree"
				+ " from incedo_dsp_schema.savedKpiTree where kpi_tree_id=" + id;
		logger.info("saveDynamicTree GET SQL : " + sql);
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("treeList ::::::results : " + results.size());
		JSONArray json= JsonUtil.listmap_to_json(results);
		return  JsonUtil.response(json, true);
		
	}
	
	public String putSaveDynamicTree(Integer id, String payload) {
		String jsonTree, rawTree, treeDesc = rawTree = jsonTree = "";
		Integer treeID= null;
		String sql="Update incedo_dsp_schema.savedKpiTree set ";
		JSONObject jsonObj = JSONObject.fromObject(payload);
		if(jsonObj.has("jsonTree")){jsonTree=jsonObj.getString("jsonTree");}
		if(jsonObj.has("rawtree")){rawTree=jsonObj.getString("rawtree");}
		if(jsonObj.has("treeDesc")){treeDesc=jsonObj.getString("treeDesc");}
		if(jsonObj.has("treeID")){treeID=jsonObj.getInt("treeID");}	
		
		if (jsonObj.containsKey("jsonTree") && jsonObj.containsKey("rawTree")	&& jsonObj.containsKey("treeDesc") && treeID!=null) {
			String sql_update = sql +"tree_json= ?, raw_tree=?, kpi_tree_desc=? where kpi_tree_id =?";			
			logger.info("put: SaveDynamicTree update SQL : " + sql_update);
			Integer rows = jdbcTemplate.update(sql_update, jsonTree, rawTree, treeDesc, treeID);
			logger.info("put:SaveDynamicTree update : " + rows + " row(s) updated.");
			return JsonUtil.response("success", true);
		} else if (jsonObj.containsKey("jsonTree") && jsonObj.containsKey("rawTree")) {
			String sql_update = sql +"tree_json= ?, raw_tree=? where kpi_tree_id =?";	
			logger.info("put: SaveDynamicTree update SQL : " + sql_update);
			Integer rows = jdbcTemplate.update(sql_update, jsonTree, rawTree, treeID);
			logger.info("put:SaveDynamicTree update : " + rows + " row(s) updated.");
			return JsonUtil.response("success", true);
		} else if (jsonObj.containsKey("tree_json")) {
			String sql_update = sql +"tree_json= ? where kpi_tree_id =?";
			logger.info("put: SaveDynamicTree update SQL : " + sql_update);
			Integer rows = jdbcTemplate.update(sql_update, jsonTree, treeID);
			logger.info("put:SaveDynamicTree update : " + rows + " row(s) updated.");
			return JsonUtil.response("success", true);
		}
		return null;
	}
	
	public String postSaveDynamicTree(Integer id, String payload) {
		String jsonTree, rawTree, treeDesc = rawTree = jsonTree = "";
		Integer treeID= null;
		
		String sql_select = "SELECT * from incedo_dsp_schema.savedKpiTree where kpi_tree_id=" + id;
		String sql_insert = "INSERT INTO incedo_dsp_schema.savedKpiTree(treeID,rawTree,treeDesc,jsonTree) values (?,?,?,?)";
		String sql_update = "Update incedo_dsp_schema.savedKpiTree set tree_json= ?, raw_tree=?, kpi_tree_desc=? where kpi_tree_id =?";
		
		JSONObject jsonObj = JSONObject.fromObject(payload);
		if(jsonObj.has("jsonTree")){jsonTree=jsonObj.getString("jsonTree");}
		if(jsonObj.has("rawTree")){rawTree=jsonObj.getString("rawTree");}
		if(jsonObj.has("treeDesc")){treeDesc=jsonObj.getString("treeDesc");}
		if(jsonObj.has("treeID")){treeID=jsonObj.getInt("treeID");}		
		
		logger.info("postSaveDynamicTree select SQL : " + sql_select);
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql_select);
		logger.info("treeList ::::::results : " + results.size());

		if (results.isEmpty()) {			
			logger.info("post: SaveDynamicTree insert SQL : " + sql_insert);
			Integer rows = jdbcTemplate.update(sql_insert, treeID, rawTree, treeDesc, jsonTree);
			if (rows != 0) {
				logger.info("post: SaveDynamicTree " + treeID);
			} else {
				logger.info("post: SaveDynamicTree " + treeID);
			}
			logger.info("post: SaveDynamicTree insert : " + rows);
			return JsonUtil.response(rows, true);
		} else {			
			logger.info("post: SaveDynamicTree update SQL : " + sql_update);
			Integer rows = jdbcTemplate.update(sql_update, jsonTree, rawTree, treeDesc, treeID);
			logger.info("post: SaveDynamicTree update : " + rows + " row(s) updated.");
			return JsonUtil.response("success", true);
			}
		}
	
	public String getMainMenu(Integer project_id) {

		String sql="SELECT menu_content from incedo_dsp_schema.mainmenu where project_id="+project_id;
		logger.info("getMainMenu GET SQL : " + sql);
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		logger.info("treeList ::::::results : " + results.size());
		String json= JsonUtil.listmap_to_json_array(results);
		return  JsonUtil.response(json, true);
	
	}

	public String putMainMenu(Integer id, String payload) {
		String sql_update = "Update incedo_dsp_schema.mainmenu set menu_content=? where project_id=?";
		logger.info("put:MainMenu update SQL : " + sql_update);
		Integer rows = jdbcTemplate.update(sql_update, payload, id);
		logger.info("put:MainMenu update : " + rows +" row(s) updated.");
		return  JsonUtil.response("success", true);
	}
	
	public String postMainMenu(Integer id, String payload) {

		String sql_update = "Update incedo_dsp_schema.mainmenu set menu_content=? where project_id=?";
		logger.info("post : MainMenu update SQL : " + sql_update);
		Integer rows = jdbcTemplate.update(sql_update, payload, id);
		logger.info("post:MainMenu update : " + rows + " row(s) updated.");
		if (rows > 0) {
			return JsonUtil.response("success", true);
		} else {
			String sql_insert = "INSERT INTO incedo_dsp_schema.mainmenu(project_id,menu_content) VALUES(?,?)";
			logger.info("post : MainMenu insert SQL : " + sql_insert);
			rows = jdbcTemplate.update(sql_insert,id,payload);
			logger.info("post : MainMenu insert : " + rows);
			return JsonUtil.response("success", true);
		}

	}
}
